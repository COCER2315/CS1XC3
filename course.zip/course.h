/**
 * @file course.h
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-03
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief
 * The Course data type stores a course name with length up to 100 characters as a char array, 
 * a course code up to 10 characters as a char array, all the students enrolled in this course
 * as a pointer to an array, and the total number of students as an integer.
 */

typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


