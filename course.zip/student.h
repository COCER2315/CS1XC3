/**
 * @file student.h
 * @author your name (you@domain.com)
 * @brief A C header file containing definitions for the typedef struct Student, add_grade, average, print_student, generate_random_student.
 * @version 0.1
 * @date 2022-04-04
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief 
 * The Student data type stores a student's first and last name as char arrays with a length limit of 50
 * characters for each, the student's id as a char array with a length limit of 11 characters, the
 * student's transcript(list of grades) as a pointer to a double array, the number of grades as an integer.
 * 
 */

typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
